





<!DOCTYPE html>
<html lang="en">
<head>
	<!--
	// header
	Content-Security-Policy: upgrade-insecure-requests;

	// meta tag
	-->
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11" />
<link rel="pingback" href="https://birckk.com/xmlrpc.php" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

	
<title>Birckk &#8211; Reviews | Guides | Articles</title>
<meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Birckk &raquo; Feed" href="https://birckk.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Birckk &raquo; Comments Feed" href="https://birckk.com/comments/feed/" />
		<script type="f3ff4ab8607bb2311eaac884-text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/birckk.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.7"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://birckk.com/wp-includes/css/dist/block-library/style.min.css?ver=5.7' type='text/css' media='all' />
<link rel='stylesheet' id='colormag_google_fonts-css'  href='//fonts.googleapis.com/css?family=Open+Sans%3A400%2C600&#038;ver=5.7' type='text/css' media='all' />
<link rel='stylesheet' id='colormag_style-css'  href='https://birckk.com/wp-content/themes/birckk/style.css?ver=5.7' type='text/css' media='all' />
<link rel='stylesheet' id='colormag-fontawesome-css'  href='https://birckk.com/wp-content/themes/birckk/fontawesome/css/font-awesome.css?ver=4.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='sccss_style-css'  href='https://birckk.com/?sccss=1&#038;ver=5.7' type='text/css' media='all' />
		<script type="f3ff4ab8607bb2311eaac884-text/javascript">
			/* <![CDATA[ */
			var rcewpp = {
				"ajax_url":"https://birckk.com/wp-admin/admin-ajax.php",
				"nonce": "72bb64d7e1",
				"home_url": "https://birckk.com"
			};
			/* ]]\> */
		</script>
		<script type="f3ff4ab8607bb2311eaac884-text/javascript" src='https://birckk.com/wp-includes/js/jquery/jquery.min.js?ver=3.5.1' id='jquery-core-js'></script>
<script type="f3ff4ab8607bb2311eaac884-text/javascript" src='https://birckk.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type="f3ff4ab8607bb2311eaac884-text/javascript" src='https://birckk.com/wp-content/themes/birckk/js/colormag-custom.js?ver=5.7' id='colormag-custom-js'></script>
<link rel="https://api.w.org/" href="https://birckk.com/wp-json/" /><link rel="alternate" type="application/json" href="https://birckk.com/wp-json/wp/v2/pages/2197" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://birckk.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://birckk.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.7" />
<link rel="canonical" href="https://birckk.com/" />
<link rel='shortlink' href='https://birckk.com/' />
<link rel="alternate" type="application/json+oembed" href="https://birckk.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fbirckk.com%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://birckk.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fbirckk.com%2F&#038;format=xml" />
<style type="text/css" id="custom-background-css">
body.custom-background { background-color: #ffffff; }
</style>
	<link rel="icon" href="https://birckk.com/wp-content/uploads/Frontpage/cropped-tree-logo-1-32x32.png" sizes="32x32" />
<link rel="icon" href="https://birckk.com/wp-content/uploads/Frontpage/cropped-tree-logo-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://birckk.com/wp-content/uploads/Frontpage/cropped-tree-logo-1-180x180.png" />
<meta name="msapplication-TileImage" content="https://birckk.com/wp-content/uploads/Frontpage/cropped-tree-logo-1-270x270.png" />

<style>

.fa {
  padding: 7px;
  font-size: 20px;
  width: 20px;
  text-align: center;
}

</style>
	
</head>

<body class="home page-template-default page page-id-2197 custom-background locale-en  wide">
<div id="page" class="hfeed site">
		<header id="masthead" class="site-header clearfix">
		<div id="header-text-nav-container" class="clearfix">
         
			
			<div class="inner-wrap">

				<div id="header-text-nav-wrap" class="clearfix">
					<div id="header-left-section">
												<div id="header-text">
							<h1 id="site-title">
								<a href="https://birckk.com/" title="Birckk" rel="home">Birckk</a>
							</h1>
							<h2 id="site-description">Reviews | Guides | Articles</h2><!-- #site-description -->
						</div><!-- #header-text -->
											</div><!-- #header-left-section -->
					<div id="header-right-section">
				
				<a href="https://www.facebook.com/Birckk.idk" style="display: inline-block; border-radius: 50%; box-shadow: 0px 0px 2px #888; " target="_blank" class="fa fa-facebook"></a>
				<a href="https://twitter.com/Birckk_" style="display: inline-block; border-radius: 50%; box-shadow: 0px 0px 2px #888; " target="_blank"class="fa fa-twitter"></a>
				<a href="https://www.youtube.com/channel/UC80cL-nAT-j8XKzBdu_F6Qg" style="display: inline-block; border-radius: 50%; box-shadow: 0px 0px 2px #888; " target="_blank" class="fa fa-youtube"></a>		
				<a href="https://store.steampowered.com/curator/24320146-Birckk/" style="display: inline-block; border-radius: 50%; box-shadow: 0px 0px 2px #888; " target="_blank" class="fa fa-steam-square"></a>
				<a href="https://www.twitch.tv/birckk" style="display: inline-block; border-radius: 50%; box-shadow: 0px 0px 2px #888; " target="_blank" class="fa fa-twitch"></a>
						
				<a href="https://discordapp.com/invite/afWjb8z " style="display: inline-block; border-radius: 50%; box-shadow: 0px 0px 2px #888; color:white;" style="position:relative;" target="_blank" class="fa fa-circle" ><i style="position:absolute; left:8.7px;  color:#CCCCCC;"class="fab fa-discord"></i></a>				
						
				<a href="https://www.reddit.com/r/Birckk/" style="display: inline-block; border-radius: 50%; box-shadow: 0px 0px 2px #888; " target="_blank" class="fa fa-reddit-square"></a>
				<a href="https://www.instagram.com/birckk_/" style="display: inline-block; border-radius: 50%; box-shadow: 0px 0px 2px #888; " target="_blank" class="fa fa-instagram"></a>		
				<a href="https://github.com/Birckk" style="display: inline-block; border-radius: 50%; box-shadow: 0px 0px 2px #888; " target="_blank" class="fa fa-github"></a>
				
						
									    	</div><!-- #header-right-section -->

			   </div><!-- #header-text-nav-wrap -->

			</div><!-- .inner-wrap -->

			
			<nav id="site-navigation" class="main-navigation clearfix" role="navigation">
				<div class="inner-wrap clearfix">
					               <h4 class="menu-toggle"></h4>
               <div class="menu-primary-container"><ul id="menu-primary-menu" class="menu"><li id="menu-item-369" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-369"><a href="/" aria-current="page">Home</a></li>
<li id="menu-item-431" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-431"><a href="https://birckk.com/reviews/">Reviews</a>
<ul class="sub-menu">
	<li id="menu-item-429" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-429"><a href="https://birckk.com/reviews/gamereviews/">Games</a></li>
	<li id="menu-item-443" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-443"><a href="https://birckk.com/reviews/boardgamesreviews/">Boardgames</a></li>
	<li id="menu-item-445" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-445"><a href="https://birckk.com/reviews/moviereviews/">Movies</a></li>
	<li id="menu-item-446" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-446"><a href="https://birckk.com/reviews/animereviews/">Anime</a></li>
	<li id="menu-item-444" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-444"><a href="https://birckk.com/reviews/seriesreviews/">Series</a></li>
</ul>
</li>
<li id="menu-item-172" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-172"><a href="https://birckk.com/birckk/">Birckk</a>
<ul class="sub-menu">
	<li id="menu-item-337" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-337"><a href="https://birckk.com/birckk/portfolio/">Portfolio</a>
	<ul class="sub-menu">
		<li id="menu-item-394" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-394"><a href="https://birckk.com/birckk/portfolio/programming/">Programming</a>
		<ul class="sub-menu">
			<li id="menu-item-509" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-509"><a href="https://birckk.com/birckk/portfolio/programming/php/">PHP</a></li>
			<li id="menu-item-452" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-452"><a href="https://birckk.com/birckk/portfolio/programming/processing/">Processing</a></li>
			<li id="menu-item-1126" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1126"><a href="https://birckk.com/birckk/portfolio/programming/html/">HTML</a></li>
		</ul>
</li>
		<li id="menu-item-393" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-393"><a href="https://birckk.com/birckk/portfolio/music/">Music</a></li>
		<li id="menu-item-392" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-392"><a href="https://birckk.com/birckk/portfolio/art/">Art</a>
		<ul class="sub-menu">
			<li id="menu-item-2045" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2045"><a href="https://birckk.com/birckk/portfolio/art/illustrations/">Illustrations</a></li>
			<li id="menu-item-507" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-507"><a href="https://birckk.com/birckk/portfolio/art/pixelart/">Pixelart</a></li>
			<li id="menu-item-508" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-508"><a href="https://birckk.com/birckk/portfolio/art/fonts/">Fonts</a></li>
		</ul>
</li>
		<li id="menu-item-391" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-391"><a href="https://birckk.com/birckk/portfolio/universe/">Universe</a></li>
	</ul>
</li>
	<li id="menu-item-1323" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1323"><a href="https://birckk.com/twitch/">Twitch</a>
	<ul class="sub-menu">
		<li id="menu-item-1322" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1322"><a href="https://birckk.com/twitch/leaderboard/">Leaderboard</a></li>
		<li id="menu-item-1325" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1325"><a href="https://birckk.com/twitch/schedule/">Schedule</a></li>
	</ul>
</li>
	<li id="menu-item-335" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-335"><a href="https://birckk.com/birckk/stats/">Stats</a></li>
	<li id="menu-item-2116" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2116"><a href="https://birckk.com/birckk/gamespage/">GamesPage</a></li>
</ul>
</li>
<li id="menu-item-599" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-599"><a href="https://birckk.com/articles/">Articles</a>
<ul class="sub-menu">
	<li id="menu-item-1925" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1925"><a href="https://birckk.com/articles/guides/">Guides</a></li>
	<li id="menu-item-3329" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3329"><a href="https://birckk.com/articles/lists/">Lists</a></li>
	<li id="menu-item-1927" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1927"><a href="https://birckk.com/articles/news/">News</a></li>
	<li id="menu-item-1926" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1926"><a href="https://birckk.com/articles/updates/">Updates</a></li>
</ul>
</li>
<li id="menu-item-2006" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2006"><a href="https://birckk.com/products/">Products</a></li>
</ul></div>                                                <i class="fa fa-search search-top"></i>
                  <div class="search-form-top">
                     <form action="https://birckk.com/" class="search-form searchform clearfix" method="get">
   <div class="search-wrap">
      <input type="text" placeholder="Search" class="s field" name="s">
      <button class="search-icon" type="submit"></button>
   </div>
</form><!-- .searchform -->                  </div>
               				</div>
			</nav>

		</div><!-- #header-text-nav-container -->

		
	</header>
			<div id="main" class="clearfix">
		<div class="inner-wrap clearfix">
<style>
#main{
	padding-top:0px;
}</style>

   <div class="front-page-top-section clearfix">
      <div class="widget_slider_area">
               </div>

      <div class="widget_beside_slider">
               </div>
   </div>
   <div class="main-content-section clearfix">
      <div id="primary">
         <div id="content" class="clearfix">

         <section id="phpeverywherewidget-2" class="widget phpeverywherewidget clearfix"><h3 class="widget-title"><span> </span></h3><div id="metaslider-id-2187" style="width: 100%;" class="ml-slider-3-20-3 metaslider metaslider-flex metaslider-2187 ml-slider ms-theme-blend nav-hidden">
    <div id="metaslider_container_2187">
        <div id="metaslider_2187">
            <ul aria-live="polite" class="slides">
                <li style="display: block; width: 100%;" class="slide-2188 ms-image"><a href="https://birckk.com/reviews/" target="_self"><img src="https://birckk.com/wp-content/uploads/Frontpage/Slider/reviews-700x350.png" height="350" width="700" alt="" class="slider-2187 slide-2188" title="Reviews" /></a></li>
                <li style="display: none; width: 100%;" class="slide-2189 ms-image"><a href="https://birckk.com/articles/" target="_self"><img src="https://birckk.com/wp-content/uploads/Frontpage/Slider/slideshow-pictures-700x350.png" height="350" width="700" alt="" class="slider-2187 slide-2189" title="slideshow pictures" /></a></li>
                <li style="display: none; width: 100%;" class="slide-2190 ms-image"><a href="https://www.youtube.com/channel/UC80cL-nAT-j8XKzBdu_F6Qg" target="_blank"><img src="https://birckk.com/wp-content/uploads/Frontpage/Slider/youtube-slide-700x350.png" height="350" width="700" alt="" class="slider-2187 slide-2190" title="youtube slide" /></a></li>
                <li style="display: none; width: 100%;" class="slide-2196 ms-image"><a href="https://www.twitch.tv/birckk" target="_blank"><img src="https://birckk.com/wp-content/uploads/Frontpage/Slider/twitch-slide-700x350.png" height="350" width="700" alt="" class="slider-2187 slide-2196" title="twitch slide" /></a></li>
            </ul>
        </div>
        
    </div>
</div><br></section><section id="colormag_highlighted_posts_widget-2" class="widget widget_highlighted_posts widget_featured_meta clearfix">      <div class="widget_highlighted_post_area">
                           <div class="single-article">
               <figure class="highlights-featured-image"><a href="https://birckk.com/opus-magnum/" title="Opus Magnum"><img src="https://birckk.com/wp-content/uploads/reviews/Games/O/OpusMagnum/Opus-Magnum.png" /></a></figure>               <div class="article-content">
                  <div class="above-entry-meta"><span class="cat-links"><a href="https://birckk.com/category/reviews/gamereviews/"  rel="category tag">Games</a>&nbsp;</span></div>                  <h3 class="entry-title">
                     <a href="https://birckk.com/opus-magnum/" title="Opus Magnum">Opus Magnum</a>
                  </h3>
                  <div class="below-entry-meta">
                     <span class="posted-on"><a href="https://birckk.com/opus-magnum/" title="12:21" rel="bookmark"><i class="fa fa-calendar-o"></i> <time class="entry-date published" datetime="2020-08-07T12:21:32+00:00">07/08/2020</time></a></span>                     <span class="byline"><span class="author vcard"><i class="fa fa-user"></i><a class="url fn n" href="https://birckk.com/author/birckk/" title="Birckk">Birckk</a></span></span>
                     <span class="comments"><i class="fa fa-comment"></i><a href="https://birckk.com/opus-magnum/#respond">0</a></span>
                  </div>
               </div>

            </div>
                     <div class="single-article">
               <figure class="highlights-featured-image"><a href="https://birckk.com/beyond-eyes/" title="Beyond Eyes"><img src="https://birckk.com/wp-content/uploads/reviews/Games/B/BeyondEyes/Beyond-eyes-thumbnail.png" /></a></figure>               <div class="article-content">
                  <div class="above-entry-meta"><span class="cat-links"><a href="https://birckk.com/category/reviews/gamereviews/"  rel="category tag">Games</a>&nbsp;</span></div>                  <h3 class="entry-title">
                     <a href="https://birckk.com/beyond-eyes/" title="Beyond Eyes">Beyond Eyes</a>
                  </h3>
                  <div class="below-entry-meta">
                     <span class="posted-on"><a href="https://birckk.com/beyond-eyes/" title="10:00" rel="bookmark"><i class="fa fa-calendar-o"></i> <time class="entry-date published" datetime="2019-09-02T10:00:46+00:00">02/09/2019</time></a></span>                     <span class="byline"><span class="author vcard"><i class="fa fa-user"></i><a class="url fn n" href="https://birckk.com/author/birckk/" title="Birckk">Birckk</a></span></span>
                     <span class="comments"><i class="fa fa-comment"></i><a href="https://birckk.com/beyond-eyes/#respond">0</a></span>
                  </div>
               </div>

            </div>
                     <div class="single-article">
               <figure class="highlights-featured-image"><a href="https://birckk.com/drawful-2/" title="Drawful 2"><img src="https://birckk.com/wp-content/uploads/reviews/Games/D/Drawful2/drawful-2-thumbnail.png" /></a></figure>               <div class="article-content">
                  <div class="above-entry-meta"><span class="cat-links"><a href="https://birckk.com/category/reviews/gamereviews/"  rel="category tag">Games</a>&nbsp;</span></div>                  <h3 class="entry-title">
                     <a href="https://birckk.com/drawful-2/" title="Drawful 2">Drawful 2</a>
                  </h3>
                  <div class="below-entry-meta">
                     <span class="posted-on"><a href="https://birckk.com/drawful-2/" title="10:06" rel="bookmark"><i class="fa fa-calendar-o"></i> <time class="entry-date published" datetime="2019-08-26T10:06:41+00:00">26/08/2019</time></a></span>                     <span class="byline"><span class="author vcard"><i class="fa fa-user"></i><a class="url fn n" href="https://birckk.com/author/birckk/" title="Birckk">Birckk</a></span></span>
                     <span class="comments"><i class="fa fa-comment"></i><a href="https://birckk.com/drawful-2/#respond">0</a></span>
                  </div>
               </div>

            </div>
                     <div class="single-article">
               <figure class="highlights-featured-image"><a href="https://birckk.com/the-jackbox-party-park-5/" title="The Jackbox Party Pack 5"><img src="https://birckk.com/wp-content/uploads/reviews/Games/The/TheJackboxPartyPack5/The-Jackbox-Party-Pack-5-thumbnail.png" /></a></figure>               <div class="article-content">
                  <div class="above-entry-meta"><span class="cat-links"><a href="https://birckk.com/category/reviews/gamereviews/"  rel="category tag">Games</a>&nbsp;</span></div>                  <h3 class="entry-title">
                     <a href="https://birckk.com/the-jackbox-party-park-5/" title="The Jackbox Party Pack 5">The Jackbox Party Pack 5</a>
                  </h3>
                  <div class="below-entry-meta">
                     <span class="posted-on"><a href="https://birckk.com/the-jackbox-party-park-5/" title="10:04" rel="bookmark"><i class="fa fa-calendar-o"></i> <time class="entry-date published" datetime="2019-08-26T10:04:38+00:00">26/08/2019</time></a></span>                     <span class="byline"><span class="author vcard"><i class="fa fa-user"></i><a class="url fn n" href="https://birckk.com/author/birckk/" title="Birckk">Birckk</a></span></span>
                     <span class="comments"><i class="fa fa-comment"></i><a href="https://birckk.com/the-jackbox-party-park-5/#respond">0</a></span>
                  </div>
               </div>

            </div>
               </div>
      </section>
            <div class="article-container">
               
                  
                     
                  
                  

                           </div>
                  </div>
      </div>
      

<div id="secondary">
			
		<aside id="phpeverywherewidget-4" class="widget phpeverywherewidget clearfix"><h3 class="widget-title"><span>LiveOffline</span></h3><style>
#phpeverywherewidget-4 h3 {
display: none;
}
</style>

  <a href="https://www.twitch.tv/birckk" target="_blank" style="display: block;float:right;">
    <div class="big-div">
        <div>
          <span class="live-status-text" style="color:grey; font-size:50;" >Offline</span>
        </div>
        <div style="float:right;">
          <span class="dot offline-inner"></span>
        </div>
    </div>
  </a>
  </aside>
		<aside id="recent-posts-4" class="widget widget_recent_entries clearfix">
		<h3 class="widget-title"><span>Recent Posts</span></h3>
		<ul>
											<li>
					<a href="https://birckk.com/best-sport-anime/">Best Sport Anime</a>
									</li>
											<li>
					<a href="https://birckk.com/best-gambling-anime/">Best Gambling Anime</a>
									</li>
											<li>
					<a href="https://birckk.com/boku-dake-ga-inai-machi-erased/">Boku dake ga Inai Machi (Erased)</a>
									</li>
					</ul>

		</aside><aside id="custom_html-2" class="widget_text widget widget_custom_html clearfix"><div class="textwidget custom-html-widget"><a href="https://birckk.com/articles/news/"><img src="https://birckk.com/wp-content/uploads/Articles/news.png" alt="News"></a>
<a href="https://birckk.com/articles/updates/"><img src="https://birckk.com/wp-content/uploads/Articles/updates.png" alt="Updates"></a></div></aside>
	</div>   </div>


		</div><!-- .inner-wrap -->
	</div><!-- #main -->
   			<footer id="colophon" class="clearfix">
			
<div class="footer-widgets-wrapper">
	<div class="inner-wrap">
		<div class="footer-widgets-area clearfix">
         <div class="tg-footer-main-widget">
   			<div class="tg-first-footer-widget">
   				<aside id="linkcat-18" class="widget widget_links clearfix"><h3 class="widget-title"><span>Help</span></h3>
	<ul class='xoxo blogroll'>
<li><a href="https://birckk.com/contact">Contact</a></li>
<li><a href="https://birckk.com/faq">FAQ</a></li>

	</ul>
</aside>
   			</div>
         </div>
         <div class="tg-footer-other-widgets">
   			<div class="tg-second-footer-widget">
   				<aside id="linkcat-19" class="widget widget_links clearfix"><h3 class="widget-title"><span>Links</span></h3>
	<ul class='xoxo blogroll'>
<li><a href="https://birckk.com/about">About</a></li>
<li><a href="https://birckk.com/acknowledgements">Acknowledgements</a></li>

	</ul>
</aside>
   			</div>
            <div class="tg-third-footer-widget">
                           </div>
            <div class="tg-fourth-footer-widget">
                           </div>
         </div>
		</div>
	</div>
</div>			<div class="footer-socket-wrapper clearfix">
				<div class="inner-wrap">
					<div class="footer-socket-area">
                  <div class="footer-socket-right-section">
   						                  </div>
                  <div class="footer-socket-left-sectoin">
   						<div class="copyright">Copyright &copy; 2021 <a href="https://birckk.com/" title="Birckk" ><span>Birckk</span></a>. All rights reserved.</div>                  </div>
					</div>
				</div>
			</div>
		</footer>
		<a href="#masthead" id="scroll-up"><i class="fa fa-chevron-up"></i></a>
	</div><!-- #page -->
	<link rel='stylesheet' id='metaslider-flex-slider-css'  href='https://birckk.com/wp-content/plugins/ml-slider/assets/sliders/flexslider/flexslider.css?ver=3.20.3' type='text/css' media='all' property='stylesheet' />
<link rel='stylesheet' id='metaslider-public-css'  href='https://birckk.com/wp-content/plugins/ml-slider/assets/metaslider/public.css?ver=3.20.3' type='text/css' media='all' property='stylesheet' />
<link rel='stylesheet' id='metaslider_blend_theme_styles-css'  href='https://birckk.com/wp-content/plugins/ml-slider/themes/blend/v1.0.0/style.min.css?ver=1.0.0' type='text/css' media='all' property='stylesheet' />
<script type="f3ff4ab8607bb2311eaac884-text/javascript" src='https://birckk.com/wp-content/themes/birckk/js/jquery.bxslider.min.js?ver=4.1.2' id='colormag-bxslider-js'></script>
<script type="f3ff4ab8607bb2311eaac884-text/javascript" src='https://birckk.com/wp-content/themes/birckk/js/colormag-slider-setting.js?ver=5.7' id='colormag_slider-js'></script>
<script type="f3ff4ab8607bb2311eaac884-text/javascript" src='https://birckk.com/wp-content/themes/birckk/js/navigation.js?ver=5.7' id='colormag-navigation-js'></script>
<script type="f3ff4ab8607bb2311eaac884-text/javascript" src='https://birckk.com/wp-content/themes/birckk/js/fitvids/jquery.fitvids.js?ver=20150311' id='colormag-fitvids-js'></script>
<script type="f3ff4ab8607bb2311eaac884-text/javascript" src='https://birckk.com/wp-content/themes/birckk/js/fitvids/fitvids-setting.js?ver=20150311' id='colormag-fitvids-setting-js'></script>
<script type="f3ff4ab8607bb2311eaac884-text/javascript" src='https://birckk.com/wp-includes/js/wp-embed.min.js?ver=5.7' id='wp-embed-js'></script>
<script type="f3ff4ab8607bb2311eaac884-text/javascript" src='https://birckk.com/wp-content/plugins/ml-slider/assets/sliders/flexslider/jquery.flexslider.min.js?ver=3.20.3' id='metaslider-flex-slider-js'></script>
<script type="f3ff4ab8607bb2311eaac884-text/javascript" id='metaslider-flex-slider-js-after'>
var metaslider_2187 = function($) {$('#metaslider_2187').addClass('flexslider');
            $('#metaslider_2187').flexslider({ 
                slideshowSpeed:3000,
                animation:"fade",
                controlNav:false,
                directionNav:true,
                pauseOnHover:true,
                direction:"horizontal",
                reverse:false,
                animationSpeed:600,
                prevText:"Previous",
                nextText:"Next",
                fadeFirstSlide:true,
                slideshow:true
            });
            $(document).trigger('metaslider/initialized', '#metaslider_2187');
        };
        var timer_metaslider_2187 = function() {
            var slider = !window.jQuery ? window.setTimeout(timer_metaslider_2187, 100) : !jQuery.isReady ? window.setTimeout(timer_metaslider_2187, 1) : metaslider_2187(window.jQuery);
        };
        timer_metaslider_2187();
</script>
<script type="f3ff4ab8607bb2311eaac884-text/javascript" src='https://birckk.com/wp-content/plugins/ml-slider/themes/blend/v1.0.0/script.js?ver=1.0.0' id='metaslider_theme_five_theme_script-js'></script>
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="f3ff4ab8607bb2311eaac884-|49" defer=""></script></body>
</html>
/*This file was exported by "Export WP Page to Static HTML" plugin which created by ReCorp (https://myrecorp.com) */